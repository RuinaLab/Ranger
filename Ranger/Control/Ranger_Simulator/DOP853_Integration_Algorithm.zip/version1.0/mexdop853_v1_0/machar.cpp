#include <math.h>
#include "machar.h"

double machar_d (void) {
	/*
	Purpose:

	MACHAR_D computes machine constants for double floating point arithmetic.

	Discussion:

	This routine determines the parameters of the floating-point 
	arithmetic system specified below.  The determination of the first 
	three uses an extension of an algorithm due to Malcolm, 
	incorporating some of the improvements suggested by Gentleman and 
	Marovich.  

	A FORTRAN version of this routine appeared as ACM algorithm 665.

	This routine is a C translation of the FORTRAN code, and appeared
	as part of ACM algorithm 722.

	An earlier version of this program was published in Cody and Waite.

	Reference:

	W J Cody,
	ACM Algorithm 665, MACHAR, a subroutine to dynamically determine 
	machine parameters,
	ACM Transactions on Mathematical Software,
	Volume 14, Number 4, pages 303-311, 1988.

	W J Cody and W Waite,
	Software Manual for the Elementary Functions,
	Prentice Hall, 1980.

	M Gentleman and S Marovich,
	Communications of the ACM,
	Volume 17, pages 276-277, 1974.

	M. Malcolm,
	Communications of the ACM,
	Volume 15, pages 949-951, 1972.

	Author:

	W. J. Cody
	Argonne National Laboratory

	Modified by:
	M. Venkadesan
	Cornell University

	Parameters:

	Output, long int * IBETA, the radix for the floating-point representation.

	Output, long int * IT, the number of base IBETA digits in the floating-point
	significand.

	Output, long int * IRND:
	0, if floating-point addition chops.
	1, if floating-point addition rounds, but not in the IEEE style.
	2, if floating-point addition rounds in the IEEE style.
	3, if floating-point addition chops, and there is partial underflow.
	4, if floating-point addition rounds, but not in the IEEE style, and 
	there is partial underflow.
	5, if floating-point addition rounds in the IEEE style, and there is 
	partial underflow.

	Output, long int * MACHEP, the largest negative integer such that
	1.0 + ( double ) IBETA ^ MACHEP != 1.0, 
	except that MACHEP is bounded below by - ( IT + 3 ).

	Output, long int * NEGEPS, the largest negative integer such that
	1.0 - ( double ) IBETA ) ^ NEGEPS != 1.0, 
	except that NEGEPS is bounded below by - ( IT + 3 ).

	Output, double * EPS, the smallest positive floating-point number such
	that  
	1.0 + EPS != 1.0. 
	in particular, if either IBETA = 2  or IRND = 0, 
	EPS = ( double ) IBETA ^ MACHEP.
	Otherwise,  
	EPS = ( ( double ) IBETA ^ MACHEP ) / 2.

	Output, double * EPSNEG, a small positive floating-point number such that
	1.0 - EPSNEG != 1.0. 
	In particular, if IBETA = 2 or IRND = 0, 
	EPSNEG = ( double ) IBETA ^ NEGEPS.
	Otherwise,  
	EPSNEG = ( double ) IBETA ^ NEGEPS ) / 2.  
	Because NEGEPS is bounded below by - ( IT + 3 ), EPSNEG might not be the
	smallest number that can alter 1.0 by subtraction.

	*/

	long int ibeta;
	long int it;
	long int irnd;
	long int machep;
	long int negep;
	double eps;
	double epsneg;

	double a;
	double b;
	double beta;
	double betah;
	double betain;
	int i;
	int itmp;
	double one;
	double tmp;
	double tmp1;
	double tmpa;
	double two;
	double zero;

	(irnd) = 1;
	one = (double) (irnd);
	two = one + one;
	a = two;
	b = a;
	zero = 0.0e0;
	/*
	Determine IBETA and BETA ala Malcolm.
	*/
	tmp = ( ( a + one ) - a ) - one;

	while ( tmp == zero ) {
		a = a + a;
		tmp = a + one;
		tmp1 = tmp - a;
		tmp = tmp1 - one;
	}

	tmp = a + b;
	itmp = ( int ) ( tmp - a );

	while ( itmp == 0 ) {
		b = b + b;
		tmp = a + b;
		itmp = ( int ) ( tmp - a );
	}

	ibeta = itmp;
	beta = ( double ) ( ibeta );
	/*
	Determine IRND, IT.
	*/
	(it) = 0;
	b = one;
	tmp = ( ( b + one ) - b ) - one;

	while ( tmp == zero ) {
		it = it + 1;
		b = b * beta;
		tmp = b + one;
		tmp1 = tmp - b;
		tmp = tmp1 - one;
	}

	irnd = 0;
	betah = beta / two;
	tmp = a + betah;
	tmp1 = tmp - a;

	if ( tmp1 != zero ) {
		irnd = 1;
	}

	tmpa = a + beta;
	tmp = tmpa + betah;

	if ( ( irnd == 0 ) && ( tmp - tmpa != zero ) ) {
		irnd = 2;
	}
	/*
	Determine NEGEP, EPSNEG.
	*/
	(negep) = (it) + 3;
	betain = one / beta;
	a = one;

	for ( i = 1; i <= (negep); i++ ) {
		a = a * betain;
	}

	b = a;
	tmp = ( one - a );
	tmp = tmp - one;

	while ( tmp == zero ) {
		a = a * beta;
		negep = negep - 1;
		tmp1 = one - a;
		tmp = tmp1 - one;
	}

	(negep) = -(negep);
	(epsneg) = a;
	/*
	Determine MACHEP, EPS.
	*/

	(machep) = -(it) - 3;
	a = b;
	tmp = one + a;

	while ( tmp - one == zero) {
		a = a * beta;
		machep = machep + 1;
		tmp = one + a;
	}

	eps = a;

	return (eps);
}

