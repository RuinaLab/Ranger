/*	All global variables are declared within this file. That way,
	it is easy to keep track of them. These global variables are
	forward declared in the files called globals.h using the extern
	keyword. That way, every other CPP file only needs to include
	the globals header file and all will be fine. */
#include "globals.h"
#include <vector>
#include "OptionsObj.h"
#include "EventObj.h"
#include "EventPoint.h"

// The following are the outputs of MEXDOP853.
vector <double> timev;				// computed time stamps
vector < vector <double> > points;	// computed points

vector <double> te;					// time at which an event occurs
vector < vector <double> > ye;		// point at the time of the event
vector <unsigned> ie;				// index i of the event function that vanishes

// The following are globals used for the sake of bookkeeping across functions
vector <double> yout;				// output point, used by refine()
vector <double> tstep;				// A bunch of time-stamps within current step, including events and refinements
vector < vector <double> > ystep;	// Solutions points corresponding to tstep

OptionsObj options;					// Options class 
EventObj events;					// for event detection / location

