function varargout = dop853(varargin)
%DOP853 Use a Dormand-Prince 8(5,3) algorithm for forward integration of
%       ordinary differential equations. The following are all valid ways
%       to call this function.
%
%               [t,y] = dop853(odefun,tspan,y0,options,params)
%               [t,y] = dop853(odefun,tspan,y0,params)
%               [t,y] = dop853(odefun,tspan,y0,options)
%               [t,y] = dop853(odefun,tspan,y0)
%         [t,y,stats] = dop853(...)
%      [t,y,te,ye,ie] = dop853(...)
%[t,y,te,ye,ie,stats] = dop853(...)
%                 sol = dop853(...)
%
%   Input arguments
%           odefun     :    A string that contains the name of the C++ file
%                           where the function F of the ODE: ydot = F(t,y,params)
%                           is defined. Example file: lorenz.cpp
%           tspan      :    [tstart,tend]
%           y0         :    A vector of initial conditions. Can be a row or
%                           a column vector.
%           options    :    A struct with the options needed for the
%                           integrator. This struct has to be created using
%                           the function DOPSET. If this entry if empty,
%                           then it must be skipped, do not set to [].
%           params     :    These are parameters that are needed for the
%                           right-hand-side of ODEFUN. This has to be a
%                           vector of numbers. If there are no parameters,
%                           then skip this entry, do not set to [].
%
%   Output arguments
%           t          :    A column vector of time-stamps output by the
%                           integrator.
%           y          :    A matrix where each column corresponds to a
%                           specific dimension of the ODE state vector and
%                           each row corresponds to the same row in t.
%           stats      :    [nFuncEvals; nSteps; nAccepted; nRejected] are
%                           numbers that tell you about the computational
%                           load associated with the current solution.
%           te         :    A column vector of time-stamps at which events
%                           were detected.
%           ye         :    A matrix where each column corresponds to a
%                           specific dimension of the ODE state vector and
%                           each row corresponds to the same row in te.
%           ie         :    A column vector of integers that are the
%                           indices the event function that vanished at the
%                           time-stamp given by te.
%           sol        :    This is a MATLAB struct with all the solutions
%                           outputs as fields of the struct.
%
%   Keep in mind that although DOP853 provides a very convenient interface
%   that is very similar to ODE45, it carries the overhead of parsing the
%   user input. Still, the speed-up is ~100 times. However, if you were to
%   run DOP853 once using a very short TSPAN, it will generate a MEX file
%   in the same folder as ODEFUN with the name dop853_<ODEFUN>.<mexext>. You
%   can perform the same integration by directly calling this MEX file as
%   follows: [T,Y,STATS] = dop853_<ODEFUN>(TSPAN,Y0,OPTIONS,PARAMS) and
%   expect to get a speed-up of ~ 1000 times.
%
%   See also DOPSET, DOPGET, MAKEDOP853.

% Madhusudhan Venkadesan, mv72@cornell.edu
%

% Input checking.
% Check to see if the correct number of inputs are given for the latest
% implementation of this function.

VERBOSE = 0; % For debugging purposes

if VERBOSE
    disp(' ');
    disp('Input and output arguments check...');
end

% Are there enough input arguments?
if nargin<3 || nargin>5
    error('DOP853:IncorrectInputs','There can only be 3, 4 or 5 input arguments.');
end

% Are there too many outut arguments?
if nargout>6
    error('DOP853:IncorrectOutputs','There can be at most 6 output arguments.');
end

% Are the first 3 mandatory input arguments of the correct type?
if ischar(varargin{1})
    odefun = varargin{1};
elseif isa(varargin{1},'function_handle')
    odefun = func2str(varargin{1});
else
    error('DOP853:IncorrectInputType','Input 1 can only be a string or a function handle.');
end

if isnumeric(varargin{2}) && min(size(varargin{2}))==1
    tspan = varargin{2};
else
    error('DOP853:IncorrectInputType','Input 2 can only be a 1D vector of numbers.');
end

if isnumeric(varargin{3}) && min(size(varargin{3}))==1
    y0 = varargin{3};
else
    error('DOP853:IncorrectInputType','Input 3 can only be a 1D vector of numbers.');
end

options = dopset;
params = [];

% If there are more than 3 arguments, then based on argument type, it has
% to be either the options structure or params array to be passed to ODEFUN
switch nargin
    case 4
        if isstruct(varargin{4})
            options = varargin{4};
        else
            params = varargin{4};
        end
    case 5
        if isstruct(varargin{4})
            options = varargin{4};
            params = varargin{5};
        else
            error('DOP853:IncorrectInputType','Inputs 4 and 5 are incorrect. See HELP DOP853.');
        end
end

% See if one and only one ODEFUN in C/C++ format exists.
if VERBOSE
    disp(['Searching for ODE function: ''' odefun ''' as a C/C++ file...']);
end
odefunexts = {'c','cpp','cxx','cc'};
desiredcppext = 'cpp';
odefunlist = strcat(odefun,'.',odefunexts);
odefunexist = [];
for i=1:length(odefunlist)
    odefunexist = [odefunexist;which(odefunlist{i},'-all')];
end

if isempty(odefunexist)
    error('DOP853:ODEFUNNotFound', ['There is no C/C++ file with the name ' odefun '.']);
elseif length(odefunexist)==1
    [odefunpath,oldodefunname,oldodefunext] = fileparts(odefunexist{:});
    oldodefunext = oldodefunext(2:end); % fileparts outputs the extension as '.EXT', while we only want 'EXT'
    oldodefunnname = [oldodefunname '.' oldodefunext];
    odefunname = strcat(odefun,'.',desiredcppext); % This is the unique C++ ODEFUN
    if ~strcmpi(oldodefunnname,odefunname)
        disp('The vector field function should be in a file with extension: ''CPP''.');
        disp(['Renaming ' oldodefunnname ' to ' odefunname]);
        status = movefile(oldodefunnname,odefunname);
        if ~status
            error('DOP853:CPPRenameFailed',['Something went wrong when renaming ' oldodefunnname ' to ' odefunname]);
        end
    end
else
    error('DOP853:TooManyODEFUN',...
        ['Too many C/C++ files with the name ' odefun '. Delete redundant files.']);
end


% Now, let's build the MEX file for this ODEFUN.
[mexfile,mexpath] = makedop853(odefun,(options.Events>0),odefunpath);
mexfile = str2func(mexfile); % Convert the string to a function handle

% Now, all the preliminary prep is done. Ready to call the MEX file and
% integrate away!
if VERBOSE
    disp('Starting integration...');
end
curdir = pwd;
cd(mexpath);
if isempty(params)
    if options.Events>0
        [t,y,te,ye,ie,stats] = mexfile(tspan,y0,options);
    else
        [t,y,stats] = mexfile(tspan,y0,options);
        te = [];
        ye = [];
        ie = [];
    end
else
    if options.Events>0
        [t,y,te,ye,ie,stats] = mexfile(tspan,y0,options,params);
    else
        [t,y,stats] = mexfile(tspan,y0,options,params);
        te = [];
        ye = [];
        ie = [];
    end
end
cd(curdir);

% Output checking.
switch nargout
    case {0,1}
        if options.Events>0
            sol = struct('t',t,'y',y,'te',te,'ye',ye,'ie',ie,'stats',stats);
        else
            sol = struct('t',t,'y',y,'stats',stats);
        end
        varargout = {sol};
    case 2
        varargout{1} = t;
        varargout{2} = y;
    case 3
        varargout{1} = t;
        varargout{2} = y;
        varargout{3} = stats;
    case 4
        varargout{1} = t;
        varargout{2} = y;
        varargout{3} = te;
        varargout{4} = stats;
    case 5
        varargout{1} = t;
        varargout{2} = y;
        varargout{3} = te;
        varargout{4} = ye;
        varargout{5} = stats;
    case 6
        varargout{1} = t;
        varargout{2} = y;
        varargout{3} = te;
        varargout{4} = ye;
        varargout{5} = ie;
        varargout{6} = stats;
    otherwise
        error('DOP853:IncorrectNumberOutputs',...
            'Incorrect number of outputs. See DOP853.');
end
