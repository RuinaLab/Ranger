function options = dopset(varargin)
%DOPSET Create/alter DOP853 OPTIONS structure.
%   OPTIONS = DOPSET('NAME1',VALUE1,'NAME2',VALUE2,...) creates an
%   integrator options structure OPTIONS in which the named properties have
%   the specified values.  Any unspecified properties have default values.
%   It is sufficient to type only the leading characters that uniquely
%   identify the property.  Case is ignored for property names.
%   
%   OPTIONS = DOPSET(OLDOPTS,'NAME1',VALUE1,...) alters an existing options
%   structure OLDOPTS.
%   
%   OPTIONS = DOPSET(OLDOPTS,NEWOPTS) combines an existing options structure
%   OLDOPTS with a new options structure NEWOPTS.  Any new properties
%   overwrite corresponding old properties.
%   
%   DOPSET with no input arguments displays all property names and their
%   possible values.
%   
%DOPSET PROPERTIES
%   
%RelTol - Relative error tolerance  [ positive scalar {1e-6} ]
%
%AbsTol - Absolute error tolerance  [ positive scalar {1e-8} ]
%   
%Refine - Output refinement factor  [ positive integer {0} ]
%   
%Stats - Display computational cost statistics  [ on | {off} ]
%   
%Events - Number of events  [ positive integer {0} ]
%
%MaxBisect - Maximum iterations for locating events [ positive integer {256} ]
%   
%MaxEventRecursions - Maximum iterations for detecting event interval [ positive integer {16} ]
%
%MaxStepSize - Upper bound on step size  [ positive scalar {max(tspan)-min(tspan)} ]
%   MaxStepSize defaults to the tspan interval.
%
%InitialStep - Suggested initial step size  [ positive scalar {0.0} ]
%   The solver will try this first.  By default the solver determines an
%   initial step size automatically.
%   
%MaxSteps - Maximum order of steps to take  [ positive integer {131072} ]
%   
%Safety - Safety factor for DOP853  [ positive scalar {0.9} ]
%   This has to be 1e-4 <= Safety <= 1
%   
%Fac1 - Parameter 1 for step size selection  [ positive scalar {0.333} ]
%   
%Fac2 - Parameter 2 for step size selection  [ positive scalar {6.0} ]
%   
%Beta - For step size stabilization  [ positive scalar {0.0} ]
%   This has to be 0 < Beta < 0.2
%   
%   See also DOPGET, DOP853, MAKEDOP853.

%   Madhusudhan Venkadesan, 7-March-2008

% Print out possible values of properties.
if (nargin == 0) && (nargout == 0)
  fprintf('             AbsTol: [ positive scalar {1e-8} ]\n');
  fprintf('               Beta: [ positive scalar {0.0} ]\n');
  fprintf('             Events: [ positive integer {0} ]\n');
  fprintf('         EventDelay: [ positive scalar {0} ]\n');
  fprintf('           EventTol: [ positive scalar {1e-8} ]\n');
  fprintf('               Fac1: [ positive scalar {0.333} ]\n');
  fprintf('               Fac2: [ positive scalar {6.0} ]\n');
  fprintf('        InitialStep: [ positive scalar {0.0} ]\n');
  fprintf('          MaxBisect: [ positive integer {256} ]\n');
  fprintf(' MaxEventRecursions: [ positive integer {16} ]\n');
  fprintf('           MaxSteps: [ positive integer {131072} ]\n');
  fprintf('        MaxStepSize: [ positive scalar {max(tspan)-min(tspan)} ]\n');
  fprintf('             Refine: [ nonnegative integer {0} ]\n');
  fprintf('             RelTol: [ positive scalar {1e-6} ]\n');
  fprintf('             Safety: [ positive scalar {0.9} ]\n');
  fprintf('              Stats: [ on | {off} ]\n');
  fprintf('\n');
  return;
end

Names = [
    'AbsTol                 '
    'Beta                   '
    'Events                 '
    'EventDelay             '
    'EventTol               '
    'Fac1                   '
    'Fac2                   '
    'InitialStep            '
    'MaxBisect              '
    'MaxEventRecursions     '
    'MaxSteps               '
    'MaxStepSize            '
    'Refine                 '
    'RelTol                 '
    'Safety                 '
    'Stats                  '
    ];
[m,n] = size(Names);
names = lower(Names);

defaultValues = { % In the same order as Names
    1e-8    % AbsTol
    0.0     % Beta
    0       % Events
    0.0     % EventDelay
    1e-8    % EventTol
    0.333   % Fac1
    6.0     % Fac2
    0.0     % InitialStep
    256     % MaxBisect
    16      % MaxEventRecursions
    131072  % MaxSteps
    0.0     % MaxStepSize
    0       % Refine
    1e-6    % RelTol
    0.9     % Safety
    'off'   % Stats
    };

% Combine all leading options structures o1, o2, ... in dopset(o1,o2,...).
options = [];
for j = 1:m
    options.(deblank(Names(j,:))) = defaultValues{j};
end
i = 1;
while i <= nargin
  arg = varargin{i};
  if ischar(arg)                         % arg is an option name
        break;
  end
  if ~isempty(arg)                      % [] is a valid options argument
    if ~isa(arg,'struct')
      error(['Expected argument %d to be a string property name ' ...
                     'or an options structure\ncreated with ODESET.'], i);
    end
    for j = 1:m
      if any(strcmp(fieldnames(arg),deblank(Names(j,:))))
        val = arg.(deblank(Names(j,:)));
      else
        val = [];
      end
      if ~isempty(val)
        options.(deblank(Names(j,:))) = val;
      end
    end
  end
  i = i + 1;
end

% A finite state machine to parse name-value pairs.
if rem(nargin-i+1,2) ~= 0
  error('Arguments must occur in name-value pairs.');
end
expectval = 0;                          % start expecting a name, not a value
while i <= nargin
  arg = varargin{i};
    
  if ~expectval
    if ~ischar(arg)
      error('Expected argument %d to be a string property name.', i);
    end
    
    lowArg = lower(arg);
    j = strmatch(lowArg,names);
    if isempty(j)                       % if no matches
      error('Unrecognized property name ''%s''.', arg);
    elseif length(j) > 1                % if more than one match
      % Check for any exact matches (in case any names are subsets of others)
      k = strmatch(lowArg,names,'exact');
      if length(k) == 1
        j = k;
      else
        msg = sprintf('Ambiguous property name ''%s'' ', arg);
        msg = [msg '(' deblank(Names(j(1),:))];
        for k = j(2:length(j))'
          msg = [msg ', ' deblank(Names(k,:))];
        end
        error('%s).', msg);
      end
    end
    expectval = 1;                      % we expect a value next
    
  else
    options.(deblank(Names(j,:)))= arg;
    expectval = 0;
      
  end
  i = i + 1;
end

if expectval
  error('Expected value for property ''%s''.', arg);
end
