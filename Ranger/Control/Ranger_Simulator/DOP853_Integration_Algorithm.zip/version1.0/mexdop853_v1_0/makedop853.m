function varargout = makedop853(vfieldname,event,varargin)
%MAKEDOP853 Build the MEX file for the ODE.
% [MEXFILE,MEXPATH]  = MAKEDOP853(VFNAME,EVENT)
%             [...]  = MAKEDOP853(VFNAME,EVENT,OPTS)
%             [...]  = MAKEDOP853(VFNAME,EVENT,EXEPATH)
%
% If only two input arguments are provided, then MAKEDOP853 will check to
% see if system-wide preferences are setup for MEXDOP853 and rely on that
% to obtain SRCPATH and GSLPATH. However, EXEPATH has to be supplied as a
% third argument (string type) or as a subfield of the OPTS struct.
% Otherwise, it will default to PWD.
%
%      VFNAME (req)  : A string that contains the name of the CPP file with
%                      the vector field. DO NOT include the file extension.
%                      The file extension is assumed to be .cpp
%       EVENT (req)  : Boolean 0 or 1 to indicate whether an event function
%                      is provided by the user or not
%        OPTS (opt)  : A Matlab struct with the following fields.
%OPTS.SRCPATH (opt)  : Path for the dop853 source files. This is an
%                      optional input. The default is assumed to be PWD.
%OPTS.EXEPATH (opt)  : Path where the final MEX file should be saved. This
%                      is also an optional input and defaults to PWD.
%OPTS.GSLPATH (opt)  : Path where the GSL folders lib, include and bin are
%                      located in case the ODEFUN uses some of the GSL
%                      functions. If this is empty, it will be assumed that
%                      GSL folders are not located and we don't care about
%                      them.
%     EXEPATH (opt)  : Path where the final MEX file should be saved. This
%                      is an optional input and defaults to PWD.
%
%           MEXFILE  : The name of the created MEX file.
%           MEXPATH  : Location of the created MEX file.
%
%   MAKEDOP853 without any input arguments prints this help file.

%   Madhusudhan Venkadesan, 11-March-2008

VERBOSE = 0;
GSLEXISTS = 0;
try
    if ispc
        objext = 'obj';
    elseif isunix
        objext = 'o';
    end

    cppext = 'cpp';

    templatefileslist = {'EventObj',...
        'EventPoint',...
        'OptionsObj',...
        'globals',...
        'integrator',...
        'machar',...
        'mexdop853',...
        'templates',...
        'utilfuncs'};

    switch nargin
        case {0,1}
            makedop853_doc;
            varargout = {};
            return
        case 2
            [userdir,vfieldname] = fileparts(vfieldname);
            if ispref('mexdop853')
                srcdir = getpref('mexdop853','srcpath');
                gsldir = getpref('mexdop853','gslpath');
            else
                srcdir = pwd;
                gsldir = '';
            end
            if isempty(userdir)
                userdir = pwd;
            end
        case 3
            if isstruct(varargin{1})
                srcdir = varargin{1}.srcpath;
                userdir = varargin{1}.exepath;
                gsldir = varargin{1}.gslpath;
            elseif ischar(varargin{1})
                if ispref('mexdop853')
                    srcdir = getpref('mexdop853','srcpath');
                    gsldir = getpref('mexdop853','gslpath');
                else
                    srcdir = pwd;
                    gsldir = '';
                end
                userdir = varargin{1};
            else
                error('MAKEDOP853:InCorrectInput','The third input should be a struct or string. Type >> help makedop853');
            end
        otherwise
            error('MAKEDOP853:IncorrectInputs','Too many inputs provided.');
    end
    if isempty(srcdir)
        srcdir = pwd;
    elseif ~isdir(srcdir)
        error('MAKEDOP853:PathNotFound','No such path for source files.');
    end
    if isempty(userdir)
        userdir = pwd;
    elseif ~isdir(userdir)
        error('MAKEDOP853:PathNotFound','No such path for creating final MEX file.');
    end
    if ~isempty(gsldir)
        if ~isdir(gsldir)
            error('MAKEDOP853:PathNotFound','No such path for GSL.');
        else
            gslincludedir = fullfile(gsldir,'include'); % The GSL header files are themselves located in gslincludedir/include
            gsllibdir = fullfile(gsldir,'lib');
%             gslbindir = fullfile(gsldir,'bin'); % We will need it if we call GSL functions using the dynamic libraries.
            if (exist('gslincludedir','var') && ~isdir(gslincludedir))
                error('MAKEDOP853:PathNotFound','No such path for GSL include files.');
            end
            if (exist('gsllibdir','var') && ~isdir(gsllibdir))
                error('MAKEDOP853:PathNotFound','No such path for GSL library files.');
            end
            if (exist('gslbindir','var') && ~isdir(gslbindir))
                error('MAKEDOP853:PathNotFound','No such path for GSL binary files.');
            end
            GSLEXISTS = 1; % This way, we will know that all's well with GSL
        end
    end

    if (event>0)
        fileslist = templatefileslist;
    elseif (event==0)
        fileslist = [templatefileslist,{'eventfunc'}];
    else
        error('MAKEDOP853:UnknownEvents','The second input (EVENT) should be either 0 or 1');
    end


    if (nargout>2)
        error('MAKEDOP853:IncorrectOutputs','Too many outputs requested.');
    end

    objdir = fullfile(srcdir,'compiledobjects','');
    if ~isdir(objdir)
        if VERBOSE
            disp('Creating folder to store compiled object files...');
        end
        mkdir(objdir);
    end

    outputname = ['dop853_' vfieldname];

    vffdate = dir(fullfile(userdir,[vfieldname '.' cppext]));
    mexdate = dir(fullfile(userdir,[outputname '.' mexext]));

    if isempty(vffdate)
        error('MAKEDOP853:MissingVfieldfunc',['There is no file named ' vfieldname '.' cppext]);
    end

    if ~isempty(mexdate) && (datenum(mexdate.date) > datenum(vffdate.date))
        if VERBOSE
            disp([vfieldname '.' cppext ' has not changed since last build of ' outputname '.' mexext]);
        end
        mexfilename =  fullfile(userdir,[outputname '.' mexext]);
        [mexpath,mexfile] = fileparts(mexfilename);
        varargout(1) = {mexfile};
        if nargout==2
            varargout(2) = {mexpath};
        end
        return
    end

    warncount = 0;
    objstring = [];

    for i = 1:length(fileslist)
        curfile = deblank(fileslist{i}); % deblank just removes any blanks in the file name
        if ~(exist(fullfile(srcdir,[curfile '.' cppext]),'file')==2)
            warning('MAKEDOP853:MissingCPPFile',['Missing file ' curfile '.' cppext '. Not compiling it']);
            warncount = warncount+1;
            continue;
        end
        cppdate = dir(fullfile(srcdir,[curfile '.' cppext]));
        objdate = dir(fullfile(objdir,[curfile '.' objext]));
        if ~isempty(objdate) && (datenum(objdate.date) > datenum(cppdate.date))
            if VERBOSE
                disp(['No changes in ' curfile '.' cppext ' since last compile. Skipping it...']);
            end
            continue;
        end
        disp(['Compiling ' curfile  '.' cppext ' ...'])
        feval(@mex,'-c',fullfile(srcdir,[curfile '.' cppext]),'-outdir',objdir);
    end

    % There will be a bunch of strange looking '''' in several places below.
    % That is because, the path names (especially on Windows and Mac OS) can
    % have a space. Blank spaces of that nature will confuse the eval commands.
    % A cleverer alternative will be to use feval. However, we will need to
    % know the number of arguments we want to pass apriori. That is painful in
    % case the DOP853 code is itself in flux. We want to be able to specify the
    % files to be compiled in fileslist and be done. That's why this somewhat
    % convoluted way of calling mex.
    for i = 1:length(fileslist)
        curfile = deblank(fileslist{i});
        objstring = [objstring, ' ', '''', fullfile(objdir, [curfile  '.' objext]), ''''];
    end
    vfieldcppfile = fullfile(userdir,[vfieldname '.' cppext]);
    mexfiles = [objstring ' ' '''' vfieldcppfile ''''];
    if GSLEXISTS
        includestr = ['-I' '''' gslincludedir '''' ' -I' '''' srcdir ''''];
        libstr = ['-L' '''' gsllibdir '''' ' -lcblas -lgsl'];
    else
        includestr = [' -I' '''' srcdir ''''];
        libstr = '';
    end

    if warncount>0
        disp(' ');
        disp('Some source files missing, so the linking');
        disp('process is probably going to fail.');
        disp('Trying it anyway...');
        disp(' ');
    end

    % Before MEX-ing, let's make sure that the output file is not sitting
    % in memory currently.
    clear(outputname);

    if (VERBOSE)
        eval(['mex -v -output ' '''' fullfile(userdir,outputname) '''' mexfiles ' ' includestr ' ' libstr]);
    else
        eval(['mex -output ' '''' fullfile(userdir,outputname) '''' mexfiles ' ' includestr ' ' libstr]);
    end

    mexfilename =  fullfile(userdir,[outputname '.' mexext]);
    [mexpath,mexfile] = fileparts(mexfilename);
    varargout(1) = {mexfile};
    if nargout==2
        varargout(2) = {mexpath};
    end

catch
    rethrow(lasterror);
end

end

function makedop853_doc()

help makedop853;

end

