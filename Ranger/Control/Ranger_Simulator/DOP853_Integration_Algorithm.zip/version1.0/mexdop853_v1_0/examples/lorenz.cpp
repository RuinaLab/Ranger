#include "vfieldfunc.h"
#include "matrix.h"

/* Lorenz Vector Field.

 Input:  (t, Y, p)
    t -- scalar (ignored)
    Y -- phase-space vector [x; y; z]
    p -- parameter vector [s; r; b]

 Output: 3-vector f = [x_dot; y_dot; z_dot] where

   x_dot = -s*x + s*y
   y_dot =  r*x -   y  - x*z
   z_dot =  y*x        - b*z
*/

static double s, r, b;	// These will be initialized by vfieldfuncinit before the integration begins

void vfieldfunc(unsigned n,  double t, double* y,  mxArray* params, double* f)
{
//static int funcounter = 0;
//
//	if (funcounter < 1)
//	{
		double* paramsarray = mxGetPr(params);
		s = paramsarray[0];
		r = paramsarray[1];
		b = paramsarray[2];
		//s = mxGetScalar(mxGetField(params,0,"s"));
		//r = mxGetScalar(mxGetField(params,0,"r"));
		//b = mxGetScalar(mxGetField(params,0,"b"));

	//	funcounter++;
	//}

	f[0] = s*(y[1] - y[0]);
	f[1] = -y[0]*y[2] + r*y[0] - y[1];
	f[2] = y[0]*y[1] - b*y[2];
} 

/* when zdot = 0 */
void eventfunc (unsigned ndims, double t, double *y, mxArray* params,
					   int ievent, double &value, int &isterminal, int &direction)
{
	switch (ievent)
	{
	case 0:
		value = y[0]*y[1] - b*y[2];
//		value = 1;
		isterminal = 0;
		direction = 1;
		break;
	}
}
