// This will be included in the build IFF options.Events == 0. The
// reason behind this apparently strange conditional building is because
// if there are no events, the user has presumably not provided a definition
// for EVENTFUNC. Therefore, I will be placing a dummy substitute in here.
#include "matrix.h"

void eventfunc (unsigned ndims, double t, double *Y, mxArray *params, 
					   int ievent, double &value, int &isterminal, int &direction)
{
}
