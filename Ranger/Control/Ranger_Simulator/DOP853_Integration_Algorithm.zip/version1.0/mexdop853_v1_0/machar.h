#ifndef MACHAR_H
#define MACHAR_H

#define ABS(xxx) (( xxx > -xxx)?(xxx):(-xxx))

double machar_d (void);

#endif

