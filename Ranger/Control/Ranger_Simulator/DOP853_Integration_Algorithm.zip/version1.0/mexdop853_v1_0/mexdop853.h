#ifndef DOP853_MEX_H // header guard
#define DOP853_MEX_H

extern void vfieldfunc(unsigned n, double t, double* y, mxArray* params, double* f);
extern void eventfunc (unsigned ndims, double t, double *y, mxArray* params,
					   int ievent, double &value, int &isterminal, int &direction);

#endif

