#ifndef TYPEDEFS_H
#define TYPEDEFS_H

#include <vector>
#include "matrix.h"

enum EventFlag				// Outcomes of event detection / location: self descriptive names.
{
	EventNotFound = 0,		// Used by EVENTDETECT
	EventExists = 1,		// Used by EVENTDETECT
	EventDetectFailed = 2,	// Used by EVENTDETECT
	NonterminalEvent = 3,	// Used by EVENTLOCATE
	TerminalEvent = 4,		// Used by EVENTLOCATE
	EventLocateFailed = 5	// Used by EVENTLOCATE
};

/** Presently, we don't make use of any of the following typedefs 
*	in a meaningful manner. They exist solely because in the future, 
*	we would like our code to accept the ODEFUN name as a string and 
*	in compile time be able to use the correct function. Similarly 
*	for optional user output (SolTrait) and event function (EvFunType) **/
/*
typedef void (*FcnEqDiff)(unsigned ndims,													// Number of dimensions of phase space
						  double t, double* y, double* params,								// Inputs for the ODEFUN
						  double* f);														// Output of the ODEFUN
*/
typedef void (*FcnEqDiff)(unsigned ndims,													// Number of dimensions of phase space
						  double t, double* y, mxArray* params,											// Inputs for the ODEFUN
						  double* f);														// Output of the ODEFUN
typedef void (*SolTrait)(long nr, double told, double t, double* y, unsigned n, long nmax, 
						 int* irtrn);														// *irtrn = -1 means, stop integration
/*
typedef void (*EvFunType)(unsigned ndims,													// Number of dimensions of phase space
						  double t, double* y, double *params,								// Same as the inputs of ODEFUN
						  int ievent,														// ievent < nevents. Index of the event function we want to evaluate
						  double & value, int & isterminal, int & direction);				// Outputs of the event function
*/
typedef void (*EvFunType)(unsigned ndims,													// Number of dimensions of phase space
						  double t, double* y, mxArray* params,								// Same as the inputs of ODEFUN
						  int ievent,														// ievent < nevents. Index of the event function we want to evaluate
						  double & value, int & isterminal, int & direction);				// Outputs of the event function


#endif

