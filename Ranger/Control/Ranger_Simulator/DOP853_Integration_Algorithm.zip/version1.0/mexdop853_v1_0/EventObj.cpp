#include <vector>
#include <algorithm>
#include <math.h>
#include "OptionsObj.h"
#include "EventObj.h"
#include "EventPoint.h"
#include "templates.h"
#include "typedefs.h"
#include "matrix.h"
#include "mex.h"
//#include "mexdop853.h"
#include "integrator.h"
#include "globals.h"

using namespace std;

EventObj::EventObj(void)
: nevents(0), eventtol(1e-8), maxeventsteps(200), maxeventdepth(16), macheps(1e-8)
{
}

void EventObj::initialize(unsigned ndimsin, vector<double> tspanin, vector<double> y0in,
						  OptionsObj optionsin, mxArray* odeparamsin, EvFunType evfunname)
{
	eventf = evfunname;

	ndims = ndimsin;
	odeparams = odeparamsin;
	//if (odeparamsvec.size()==0)
	//	odeparams = NULL;
	//else
	//	odeparams = &(odeparamsvec.at(0));
	macheps = optionsin.MachEps;
	nevents = optionsin.Events;
	eventtol = optionsin.EventTol;
	maxeventsteps = optionsin.MaxBisect;
	maxeventdepth = optionsin.MaxEventRecursions;
	//eventdelay = optionsin.EventDelay;			// This has not yet been implemented.

	curevent = 0;
	// Now initialize the set of internal private variables
	EventPoint pointbuffer(curevent,tspanin[0],y0in);
	pointbuffer.redoeventcalc(curevent);
	pointprev.clear();
	pointcur.clear();
	pointprev.push_back(pointbuffer);
	for (curevent=1;curevent<nevents;curevent++)
	{
		pointbuffer.initialize(curevent,tspanin[0],y0in);	// Set the current event number, t, y
		pointbuffer.redoeventcalc(curevent);				// call the event function at those values
		pointprev.push_back(pointbuffer);					// Append this pointbuffer to the previous point
	}
	pointcur = pointprev; // Because initialization happens before start of integration, current point = previous point
}

// TESTFOREVENTS is called at every successful integration step. It loops over all event functions.
EventFlag EventObj::testforevents(double x, double *y)
{
	EventFlag eventflagbuffer, alleventsstatus=EventNotFound;
	EventPoint evcurpoint, event1, event2, eventpbuffer;
	EventLocationList allevents;
	EventBracketList bracketlist, bracketlistbuffer;
	vector <double> vfsoln (y,y+ndims);

	// Loop over each event function and accumulate the event brackets
	for (curevent=0; curevent<nevents; curevent++)
	{
		// pointprev was set during initialization or at the end of event detection.
		// Both pointprev and pointcur have the correct eventnumber during EventObj initialization
		eventpbuffer.eventnumber = curevent;
		eventpbuffer.eventf = eventf;
		eventpbuffer.initialize(curevent,x,vfsoln);
		pointcur[curevent] = eventpbuffer;

		event1 = pointprev[curevent];
		event2 = pointcur[curevent];

		// See if there is any event bracket in (event1,event2] and
		// a list of event brackets are found, splice it to the master list
		niterdetect = 0;
		bracketlistbuffer = eventdetect(event1, event2);
		if (!bracketlistbuffer.empty())
			bracketlist.splice(bracketlist.end(),bracketlistbuffer);
	}

	// Now that we have a master list of events brackets we just loop over them and
	// do event location in each of those and build a masterlist of events.
	while ( !(bracketlist.empty()) )
	{
		event1 = bracketlist.front().at(0);
		event2 = bracketlist.front().at(1);
		bracketlist.pop_front();
		niterlocate = 0;
		curevent = event1.eventnumber;	// Just to be sure that this variable is properly updated
		evcurpoint = eventlocatebrent(event1, event2);
		if ( !(evcurpoint.vfsoln.empty()) )			// an event point was located without any errors
		{
			if (alleventsstatus == EventNotFound)	// this is the first event point that has been located
				alleventsstatus = NonterminalEvent;	// default it to a nonterminal event
			allevents.push_back(evcurpoint);		// add it to the allevents list
			if (evcurpoint.isterminal == 1)
				alleventsstatus = TerminalEvent;	// is it happens to be terminal, then allstatus becomes terminal
		}
	}

	allevents.sort();								// will sort by the time stamp
	eventflagbuffer = NonterminalEvent;
	while ( !(allevents.empty()) && (eventflagbuffer!=TerminalEvent) )
	{
		evcurpoint = allevents.front();
		allevents.pop_front();
		tstep.push_back(evcurpoint.time);
		ystep.push_back(evcurpoint.vfsoln);
		te.push_back(evcurpoint.time);
		ye.push_back(evcurpoint.vfsoln);
		ie.push_back(evcurpoint.eventnumber);
		eventflagbuffer = (evcurpoint.isterminal==1)?TerminalEvent:NonterminalEvent;
	}

	for (curevent=0; curevent<nevents; curevent++)
		pointprev[curevent] = pointcur[curevent];	// Now that the use for pointprev is done, let's update it
	return alleventsstatus;
}


EventBracketList EventObj::eventdetect(EventPoint & event1, EventPoint & event2)
{
	EventBracket bracket;
	EventBracketList outputbracketlist, bracketlistbuffer;

	bracket.reserve(2);

	if (niterdetect > maxeventdepth)		// In case too many iterations to locate
	{
		mexPrintf("Max iterations exceeded in EVENTDETECT %d in (%.16f,%.16f).\r\n",event1.eventnumber,event1.time,event2.time);
		return (outputbracketlist);			// Let the calling function know that things went bad
	}

	// Check if event1 or event2 has value=0 and call it an event so long as it is not the previous integration step
	if ( (event1 != pointprev[curevent]) && (fabs(event1.value) <= eventtol) )
	{
		outputbracketlist.push_back(makebracket(event1,event1));
		return outputbracketlist;
	}

	if ( (event2 != pointprev[curevent]) && (fabs(event2.value) <= eventtol) )
	{
		outputbracketlist.push_back(makebracket(event2,event2));
		return outputbracketlist;
	}

	// Now, see if there is a sign change in this window
	if ( event1.sign() != event2.sign() )
	{
		outputbracketlist.push_back(makebracket(event1,event2));
		return outputbracketlist;
	}

	// If there was no event exactly on the boundaries or no sign change,
	// we will search for double events.
	EventPoint eventm (curevent, (event1.time+event2.time)/2);	// Create a point in the middle of the boundary

	if ( (fabs(eventm.value) <= eventtol) )
	{
		outputbracketlist.push_back(makebracket(eventm,eventm));
		return outputbracketlist;
	}

	// Check to see if eventm differs in sign from event1 (and hence event2, because if we made it this
	// far in the function, event1.sign()==event2.sign()
	if ( eventm.sign() != event1.sign() )
	{
		outputbracketlist.push_back(makebracket(event1,eventm));
		outputbracketlist.push_back(makebracket(eventm,event2));
		return outputbracketlist;
	}

	// Now we know that event1, event2 and eventm are all of the same sign. So, we
	// will attempt linear extrapolations to see if I even need to search any further.
	EventPoint evextrap1 = extrapolatepoints(event2,eventm,event1.time);
	EventPoint evextrap2 = extrapolatepoints(event1,eventm,event2.time);
	if ( event1.sign() != evextrap1.sign() )
	{
		bracketlistbuffer = eventdetect(event1,eventm);
		if ( !(bracketlistbuffer.empty()) )
			outputbracketlist.splice(outputbracketlist.end(),bracketlistbuffer);
	}
	if ( event2.sign() != evextrap2.sign() )
	{
		bracketlistbuffer = eventdetect(event1,eventm);
		if ( !(bracketlistbuffer.empty()) )
			outputbracketlist.splice(outputbracketlist.end(),bracketlistbuffer);
	}

	// By now, we have exhausted all options as allowed by maxeventdepth.
	// So, let's just throw out whatever we have.
	return outputbracketlist;
}


EventBracket makebracket(EventPoint & event1, EventPoint & event2)
{
	EventBracket outputbracket;
	outputbracket.push_back(event1);
	outputbracket.push_back(event2);
	return outputbracket;
}



EventPoint EventObj::eventlocatebrent(EventPoint & eventend1, EventPoint & eventend2)
// Using Van Wijngaarden - Dekker - Brent Method from http://www.netlib.org/go/zeroin.f
// This will use the direction and isterminal conditions to make sure that an event really did occur
// at the zero-crossing of the event function. Once the event has been located, it will return an eventpoint.
{
	EventPoint eventa = eventend1, eventb = eventend2;
	// Because EVENTDETECT has already taken care of the chance that an event was located exactly
	// at the boundary of the time-interval of interest, we will not allow for that case within
	// EVENTLOCATE.
	if ( eventa.sign() == eventb.sign() )
	{
		mexPrintf("EVENTLOCATE was called with no sign change in (%.16f,%.16f).",eventa.time,eventb.time);
		return EventPoint();
	}

	// Now that we know that there is a sign change between eventa and eventb, let's carry out a lot of other
	// variable assignments and calculations before starting the event location iteration

	// If value2>value1, actualdirection = +1, elseif value2<value2, actualdirection = -1
	int actualdirection = signof<double>(eventb.value-eventa.value);	// Assumes specific ordering of a and b

	EventPoint eventc = eventb;

	// Create bunch of book-keeping variables before starting the iteration.
	double xd, xe, tol, xm, min1, min2;
	double p, q, r, s;
	EventFlag outputflag;
	for (niterlocate = 1; niterlocate <= maxeventsteps; niterlocate++)
	{
		if ( (eventb.value>0.0 && eventc.value>0.0) || (eventb.value<0.0 && eventc.value<0.0) )
		{
			eventc = eventa;
			xd = eventb.time - eventa.time;
			xe = xd;
		}

		if ( fabs(eventc.value) < fabs(eventb.value) )
		{
			eventa = eventb;
			eventb = eventc;
			eventc = eventa;
		}

		// Check to see if we have converged already
		tol = 2.0*macheps*fabs(eventb.time) + 0.5*eventtol;
		xm = 0.5*(eventc.time-eventb.time);
		if ( (fabs(xm) <= tol) || (eventb.value == 0) )
			if ( (eventb.direction == 0) || (actualdirection == eventb.direction) )
				return eventb;
			else
				return EventPoint();

		// Try do the quadratic interpolation step of this search method
		if ( (fabs(xe)>=tol) && (fabs(eventa.value) > fabs(eventb.value)) )
		{
			s = eventb.value/eventa.value;
			if ( eventa.time == eventc.time )
			{
				p = 2.0*xm*s;
				q = 1.0 - s;
			}
			else
			{
				q = eventa.value/eventc.value;
				r = eventb.value/eventc.value;
				p = s*(2.0*xm*q*(q-r) - (eventb.time-eventa.time)*(r - 1.0));
				q = (q - 1.0)*(r - 1.0)*(s - 1.0);
			}

			// Check for proper bounds
			if ( p>0.0 )
				q = -q;
			p = fabs(p);
			min1 = 3.0*xm*q - fabs(tol*q);
			min2 = fabs(xe*q);
			if ( 2.0*p < min<double>(min1,min2) )
			{						// Use quadratic interpolation if still converging superlinearly
				xe = xd;
				xd = p/q;
			}
			else
			{						// Possible less than superlinear convergence, so switch to bisection
				xd = xm;
				xe = xd;
			}
		}
		else
		{						// Use bisection
			xd = xm;
			xe = xd;
		}
		eventa = eventb;		// The previous best guess of the root is moved to eventa
		if ( fabs(xd) > tol )	// Calculate the new guess of the root and store it in eventb
			eventb.time += xd;	// Because of how we have overloaded "=", we can do this eventb will be updated
		else
			eventb.time += signof<double>(xm)*tol;
		eventb.initialize(curevent,eventb.time);	// This results in garbage = source of all my woes.
	}
	mexPrintf("Too many iterations of EVENTLOCATE in (%.16f,%.16f).\r\n", eventend1.time, eventend2.time);
	return EventPoint();		// Too many iterations, so event location has failed
}

