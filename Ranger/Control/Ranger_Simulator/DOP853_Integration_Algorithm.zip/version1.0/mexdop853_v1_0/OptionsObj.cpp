#include "templates.h"
#include <string>
#include "OptionsObj.h"
#include "machar.h"

using namespace std;

// http://www.parashift.com/c++-faq-lite/ctors.html#faq-10.6

// Default constructor with an initialization list
OptionsObj::OptionsObj()
	: AbsTol(1e-8), Beta(0.0), Events(0), EventDelay(0.0), EventTol(1e-8), 
	Fac1(0.333), Fac2(6.0), InitialStep(0.0), MachEps(1e-8), MaxBisect(256), MaxEventRecursions(16),
	MaxSteps(131072), MaxStepSize(0.0), Refine(0), RelTol(1e-6), Safety(0.9),
	Stats(false) {}

OptionsObj::OptionsObj(const mxArray *mx) {
  mxArray *fieldptr;
  string strbuffer;

  fieldptr = mxGetField(mx,0,"AbsTol");
  AbsTol = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Beta");
  Beta = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Events");
  Events = mx2T<unsigned>(fieldptr);

  fieldptr = mxGetField(mx,0,"EventDelay");
  EventDelay = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"EventTol");
  EventTol = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Fac1");
  Fac1 = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Fac2");
  Fac2 = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"InitialStep");
  InitialStep = mx2T<double>(fieldptr);

  MachEps = machar_d();

  fieldptr = mxGetField(mx,0,"MaxBisect");
  MaxBisect = mx2T<unsigned>(fieldptr);

  fieldptr = mxGetField(mx,0,"MaxEventRecursions");
  MaxEventRecursions = mx2T<unsigned>(fieldptr);

  fieldptr = mxGetField(mx,0,"MaxSteps");
  MaxSteps = mx2T<long>(fieldptr);

  fieldptr = mxGetField(mx,0,"MaxStepSize");
  MaxStepSize = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Refine");
  Refine = mx2T<unsigned>(fieldptr);

  fieldptr = mxGetField(mx,0,"RelTol");
  RelTol = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Safety");
  Safety = mx2T<double>(fieldptr);

  fieldptr = mxGetField(mx,0,"Stats");
  strbuffer = mx2T<string>(fieldptr);
  Stats = (strbuffer.compare("off")==0)?false:true;
}

