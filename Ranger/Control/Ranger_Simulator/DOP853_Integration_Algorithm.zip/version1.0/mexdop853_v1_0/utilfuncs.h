#ifndef UTILFUNCS_H // header guard
#define UTILFUNCS_H

using namespace std;

extern int checkinput(int nrhs, const mxArray* prhs[]);
extern void dopri_solout(long nr, double xold, double x, double* y, unsigned n, long nmax, int* irtrn);
extern void outputfun(double , double* y, int n);
extern void refine(int n, double xold, double x);
extern bool stepsort(int i, int j);

#endif

