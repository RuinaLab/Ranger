#ifndef GLOBALS_H // header guard
#define GLOBALS_H

/*	extern tells the compiler that these globals are defined elsewhere. */
#include <vector>
#include "OptionsObj.h"
#include "EventObj.h"
#include "EventPoint.h"

using namespace std;

extern vector <double> timev;				// computed times
extern vector <vector <double> > points;	// computed points

extern vector <double> te;					// time at which an event occurs
extern vector <vector <double> > ye;		// point at the time of the event
extern vector <unsigned> ie;				// index i of the event function that vanishes

extern vector <double> yout;				// output point, used by refine()
extern vector <double> tstep;				// A bunch of time-stamps within current step, including events and refinements
extern vector < vector <double> > ystep;	// Solutions points corresponding to tstep

extern OptionsObj options;					// options
extern EventObj events;						// for event detection / location


#endif

