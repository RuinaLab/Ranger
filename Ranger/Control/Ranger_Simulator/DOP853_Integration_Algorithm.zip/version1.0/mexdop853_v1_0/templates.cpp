#include <vector>
#include <string>
#include "mex.h"
#include "matrix.h"
#include "templates.h"

// Definitions of function defined with the mexConvert struct
template <typename T>
T mx2T(const mxArray *m) {
	mexConvert<T> mexconv;
	return mexconv.mx2T(m);
}

template <typename T>
mxArray* T2mx(const T& t) {
	mexConvert<T> mexconv;
	return mexconv.T2mx(t);
}

// mxArray <-> int

inline int mexConvert<int>::mx2T(const mxArray *m) const {
	return static_cast<int>(mxGetScalar(m));
}

mxArray* mexConvert<int>::T2mx(const int& s) const {
	mxArray *mx;
	double *p;

	mx = mxCreateDoubleMatrix(1,1,mxREAL);
	p = mxGetPr(mx);
	*p = static_cast<double>(s);

	return mx;
}

// mxArray <-> long

inline long mexConvert<long>::mx2T(const mxArray *m) const {
	return static_cast<long>(mxGetScalar(m));
}

mxArray* mexConvert<long>::T2mx(const long& s) const {
	mxArray *mx;
	double *p;

	mx = mxCreateDoubleMatrix(1,1,mxREAL);
	p = mxGetPr(mx);
	*p = static_cast<double>(s);

	return mx;
}

// mxArray <-> unsigned

inline unsigned mexConvert<unsigned>::mx2T(const mxArray *m) const {
	return static_cast<unsigned>(mxGetScalar(m));
}

mxArray* mexConvert<unsigned>::T2mx(const unsigned& s) const {
	mxArray *mx;
	double *p;

	mx = mxCreateDoubleMatrix(1,1,mxREAL);
	p = mxGetPr(mx);
	*p = static_cast<unsigned>(s);

	return mx;
}

// mxArray <-> double
inline double mexConvert<double>::mx2T(const mxArray *m) const {
	return mxGetScalar(m);
}

mxArray* mexConvert<double>::T2mx(const double& s) const {
	mxArray *mx;
	double *p;

	mx = mxCreateDoubleMatrix(1,1,mxREAL);
	p = mxGetPr(mx);
	*p = s;

	return mx;
}

// mxArray <-> vector<T>
template <typename T>
vector<T> mexConvert< vector<T> >::mx2T(const mxArray *m) const {

	int nel = (int) mxGetNumberOfElements(m);
	double *p = mxGetPr(m);
	vector<T> v(nel);
	for (int i=0; i<nel; i++)
		v[i] = static_cast<T>(p[i]);
	return v;
}

template <typename T>
mxArray* mexConvert< vector<T> >::T2mx(const vector<T>& v) const {
	mxArray *mx;
	int nel;
	double *p;

	nel = static_cast<int>(v.size());
	mx = mxCreateDoubleMatrix(nel,1,mxREAL);
	p = mxGetPr(mx);
	for (int i=0; i<nel; i++) {
		p[i] = static_cast<double>(v[i]);
	}

	return mx;
}


// mxArray <-> vector< vector<T> >
template <typename T>
vector< vector<T> >  mexConvert< vector< vector<T> > >::mx2T(const mxArray* m) const {
	int nrows = static_cast<int>(mxGetM(m));
	int ncols = static_cast<int>(mxGetN(m));

	/* We first declare p as a 2D array with nrows and ncols. A C compiler would certainly
	   object to this syntax because I am trying to declare a variabel size array. However,
	   C++ does not seem to object. In fact, if I did not have this declaration before
	   pointing p to the output of mxGetPr, I get very strange errors with an ANSI C++
	   compiler. This sort of bug-fix is undesirable, but I don't know any better. */
	//double p[nrows][ncols]; // p is declared as an array with nrows and ncols
	double* p = mxGetPr(m);
	vector< vector<T> > v(nrows, vector<T>(ncols)); // v: vector with nrows elements; each row has ncols elements

	for (int i=0; i<nrows; i++)
		for (int j=0; j<ncols; j++)
			//v[i][j] = static_cast<T>(p[i][j]);
			v[i][j] = static_cast<T>(*(p + i + j*nrows));
	return v;
}

template <typename T>
mxArray* mexConvert< vector< vector<T> > >::T2mx(const vector< vector<T> >& v) const {
	int nrows = static_cast<int>(v.size());
	int ncols = 0;
	if (nrows!=0)
		ncols = static_cast<int>(v[0].size());
	int count;

	mxArray* mx = mxCreateDoubleMatrix(nrows,ncols,mxREAL);
	double* p = mxGetPr(mx);

	for (int i=0; i<nrows; i++)
		for (int j=0; j<ncols; j++)
			*(p + i + j*nrows) = static_cast<double>(v[i][j]);
	return mx;
}

// mxArray <-> string
string mexConvert<string>::mx2T(const mxArray *m) const {

	char* str = mxArrayToString(m);
	string s(str);
	return s;
}

mxArray* mexConvert<string>::T2mx(const string& s) const {
	mxArray *mx;
	const char *str = 0;
	str = s.c_str();
	mx = mxCreateString(str);
	return mx;
}

// cell array <-> vector<T>
template <typename T>
vector<T> cell2T(const mxArray *m) {

	int nel = mxGetNumberOfElements(m);
	vector<T> v(nel);
	mxArray *cell_ptr;
	mexConvert<T> elconv;

	for (int i=0; i<nel; i++) {
		cell_ptr = mxGetCell(m,i);
		v[i] = elconv.mx2T(cell_ptr);
	}
	return v;
}

template <typename T>
mxArray* T2cell(const vector<T>& v) {
	mxArray *mx, *el;
	int nel;
	mexConvert<T> elconv;

	nel = (int) v.size();
	mx = mxCreateCellMatrix(nel,1);
	for (int i=0; i<nel; i++) {
		el = elconv.T2mx(v[i]);
		mxSetCell(mx,i,el);
	}

	return mx;
}

template <typename T>
int signof(const T& t)
{
	return (t<0)?-1:1;
}


// Just declaring the pattern for specific uses of the template function so that single-pass linkers are happy.
template double mx2T <double> (const mxArray* m);
template int mx2T <int> (const mxArray* m);
template long mx2T <long> (const mxArray* m);
template unsigned mx2T <unsigned> (const mxArray* m);
template string mx2T <string> (const mxArray* m);
template vector<unsigned> mx2T < vector<unsigned> > (const mxArray* m);
template vector<double> mx2T < vector<double> > (const mxArray* m);
template vector< vector<double> > mx2T < vector< vector<double> > > (const mxArray* m);

template mxArray* T2mx <double> (const double& t);
template mxArray* T2mx <int> (const int& t);
template mxArray* T2mx <long> (const long& t);
template mxArray* T2mx <string> (const string& t);
template mxArray* T2mx < vector<double> > (const vector<double>& t);
template mxArray* T2mx < vector<unsigned> > (const vector<unsigned>& t);
template mxArray* T2mx < vector< vector<double> > > (const vector< vector<double> >& t); 

template mxArray* T2cell < vector <double> > (const vector <vector <double> >& t);
template int signof<double> (const double& t);

