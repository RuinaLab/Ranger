#include <vector>
#include <algorithm>
#include <iterator>
#include "mex.h"
#include "globals.h"
#include "integrator.h"
#include "typedefs.h"
#include "utilfuncs.h"
#include "EventObj.h"
#include "memory.h"

using namespace std;

// The following templates for a class and function starting with name "sort" will be used by dopri_solout
template <typename Sequence>
class sortobject
{
private:
	const Sequence & the_sequence;

public:
	sortobject (const Sequence & ref)
		: the_sequence (ref)
	{}

	bool operator() (typename Sequence::size_type lhs, typename Sequence::size_type rhs) const 
	{
		return ( the_sequence[lhs] < the_sequence[rhs] );
	}
};

template <typename Sequence>
sortobject <Sequence> sortfunction ( const Sequence & seq )
{
	return ( sortobject <Sequence> (seq) );
}

template sortobject < vector<int> > sortfunction (const vector<int> & seq);


int checkinput(int nrhs, const mxArray *prhs[])
{
	int result = 0;

	switch (nrhs)
	{
	case 2:
		if (mxIsDouble(prhs[0])
			&& mxIsDouble(prhs[1]))
			result = 1;
		break;

	case 3:
		if (mxIsDouble(prhs[0])
			&& mxIsDouble(prhs[1]))	// The 3rd thing can be any mxArray. If it is a struct, it will assumed to be the options struct
			result = 1;
		break;

	case 4:
		if (mxIsDouble(prhs[0])
			&& mxIsDouble(prhs[1])
			&& mxIsStruct(prhs[2]))	// 3rd arg is the options struct, the 4th arg can be any mxArray with ODEPARAMS
			result = 1;
		break;

	default:
		result = 0;
		break;
	}
	
	return (result);
}

void outputfun(double t, double* y, int n) 
{
	vector<double> vy(y,y+n);

	// do a push_back if t is within machine precision of wanted time-step. It not use contd8
	points.push_back(vy);
	timev.push_back(t);

	return;
}

// Refinment function, called from solout()
void refine(int n, double xold, double x) 
{ 
	int i, j;
	int r=options.Refine;

	double dx = (x - xold) / (r+1);
	double t = xold;

	if (yout.empty())    // init yout;
	{
		yout.assign(n,0.0);
	}

	for (j=0; j<r ; j++)
	{
		t = t+dx;
		for (i=0; i<n; i++)
			yout[i] = contd8(i, t);

		tstep.push_back(t);
		ystep.push_back(yout);
		//outputfun( t, &(yout[0]), n);
	}
}

// Branch-out function, called after each accepted point
void dopri_solout(long nr, double xold, double x, double* y, unsigned n, long nmax, int* irtrn)
{
	/* Note on implementing outputs at fixed time-stamps:
			This is the place to do it. If xold <= xdesired <= x
			then use the contd8 to find y[] at xdesired and pass that
			to the outputfun. */
	unsigned i = 0;
	EventFlag eventoutcome = EventNotFound;
	vector <unsigned> idxstep;
	*irtrn = 0;  // stop-flag unset

	// Just output the initial point
	if (timev.empty()) {
		outputfun(x, y, n);
		return;
	}

	// Do refinement and append to tstep and ystep
	if (options.Refine > 0)
		refine(n, xold, x);

	// Check for events and if they exist, tstep and ystep will contain all time-stamps and solutions of events in this integration step
	if ( options.Events > 0 )
	{
		eventoutcome = events.testforevents(x, y);
		*irtrn = (eventoutcome==TerminalEvent)?-1:0;	// If there was any terminal event, stop integration
	}

	if (options.Events > 0 || options.Refine > 0)
	{
		for (i=0; i<tstep.size(); i++)
			idxstep.push_back(i);
	}

	// If nevents>0 && eventsexist && nrefine>0, then we need to sort the tstep and ystep vectors
	if ( (options.Events>0) && ( (eventoutcome==TerminalEvent) || (eventoutcome==NonterminalEvent) ) && (options.Refine>0) )
	{
		// Sort the vector idxstep by asceding order of tstep
		sort(idxstep.begin(),idxstep.end(),sortfunction(tstep));
	}

	// Now we know that tstep and ystep will be properly sorted, so just append them to timev and points and clear them
	if ( (options.Events>0) || (options.Refine>0) )
	{
		for (i=0;i<idxstep.size();i++)
		{
			timev.push_back(tstep[ idxstep[i] ]);
			points.push_back(ystep[ idxstep[i] ]);
		}
		tstep.clear();
		ystep.clear();
		idxstep.clear();
	}

	// Output this point only if *irtrn continues to remain non-negative
	if (*irtrn < 0)
		return;
	else
		outputfun(x, y, n);

	// Check limit on number of points
	if (timev.size() >= nmax)
		*irtrn = -1;             // set stop-flag
}

