// dop853_mex.c : mex-function interface implentation file
#define NLHSMIN 2

#include <vector>
#include <stdlib.h>
#include "mex.h"
#include "matrix.h"
#include "mexdop853.h"
#include "EventObj.h"
#include "globals.h"
#include "integrator.h"
#include "machar.h"
#include "OptionsObj.h"
#include "templates.h"
#include "typedefs.h"
#include "utilfuncs.h"

using namespace std;

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{ 
	if (nlhs < NLHSMIN || !(checkinput(nrhs, prhs)))
		mexErrMsgTxt("Incorrect input/output arguments. Type HELP DOP853.");

	vector <double> tspan = mx2T < vector <double> > (prhs[0]); // get tspan
	double tbegin = tspan.front();
	double tend = tspan.back();
	vector <double> y0 = mx2T < vector<double> > (prhs[1]); // initial conditions
	mxArray* params = NULL; // define an mxArray that will hold the params
	double* pars = NULL; // define a null pointer for the parameters

	if (nrhs==3 && !mxIsStruct(prhs[2]))
	{
		params = const_cast< mxArray* >(prhs[2]);
	}
	else if (nrhs==3 && mxIsStruct(prhs[2]))
	{
		options = OptionsObj(prhs[2]); // Initialize options as specified by user.
	}
	else if (nrhs==4)
	{
		options = OptionsObj(prhs[2]); // Initialize options as specified by user.
		params = const_cast< mxArray* >(prhs[3]); // parameters for RHS of ODE
		//pars = static_cast<double*>(&(params[0]));
	}

	// Set DOP853 parameters
	// Automatically determined and not reliant on user input
	unsigned n = static_cast<unsigned>(y0.size());		// phase-space dimention
	int itoler = 0;					// scalar error tolerance
	int iout = 1;                   // call solout on every iteration
	int meth = 1;					// switch for the choice of the coefficients (it seems if meth <0 or >2, then error, else reset to 1 in dopcor)
	long nstiff = -1;				// disable stiffness test
	unsigned nrdens = n;		// dense output on all components
	unsigned *icont = 0;			// when nrdens = n there is no need allocating memory for icont
	unsigned licont = n;			// declared length of icon
	double mach_eps = options.MachEps; // machine epsilon on-the-fly


	// The following parameters are user specified
	double abstol = options.AbsTol;
	double beta = options.Beta;
	bool numofevents = options.Events;
	double fac1 = options.Fac1;
	double fac2 = options.Fac2;
	double hinit = options.InitialStep;
	int maxbisect = options.MaxBisect;
	long maxsteps = options.MaxSteps;
	double hmax = options.MaxStepSize;
	int refine = options.Refine;
	double reltol = options.RelTol;
	double safety = options.Safety;
	bool stats = options.Stats;

	// Reserve space for the global time-stamps and trajectory using nmax
	//if (tspan.size() > 2)	// This will be the way to go about calculating outputs at fixed time-steps
	//	//timev = tspan;
	//else
	//{
		timev.reserve(maxsteps); // time-stamps
		points.reserve(maxsteps); // trajectory
		tstep.reserve(numofevents + refine); // Used in storing sorted time-stamps if there are events and refinements
		ystep.reserve(numofevents + refine); // Used in storing solution points sorted by time-stamps stored in tstep
	//}

	// If options.Events>0 then initialize the members of the events object
	if ( options.Events > 0 )
		events.initialize(n,tspan,y0,options,params,eventfunc);

	int idid = dop853(n, vfieldfunc, tbegin, &(y0[0]), tend, params,
		&reltol, &abstol, itoler, dopri_solout, iout, mach_eps,
		safety, fac1, fac2, beta, hmax, hinit,
		maxsteps, meth, nstiff, nrdens, icont, licont);

	// Integration statistics
	vector <double> statsoutput(4,0.0);
	statsoutput[0] = static_cast<double>(nfcnRead());
	statsoutput[1] = (double) nstepRead();
	statsoutput[2] = (double) naccptRead();
	statsoutput[3] = (double) nrejctRead();

    // Save last step-size
    double hlast = hRead();

	// return the outputs
    plhs[0] = T2mx < vector<double> > (timev);
    plhs[1] = T2mx < vector <vector<double> > > (points);

	int lhsoutputcount = 2;
	if ( options.Events > 0 )
	{
		if ( nlhs > lhsoutputcount )
		{
			plhs[lhsoutputcount] = T2mx < vector<double> > (te);
			lhsoutputcount++;
		}
		if ( nlhs > lhsoutputcount )
		{
			plhs[lhsoutputcount] = T2mx < vector <vector<double> > > (ye);
			lhsoutputcount++;
		}
		if ( nlhs > lhsoutputcount )
		{
			plhs[lhsoutputcount] = T2mx < vector<unsigned> > (ie);
			lhsoutputcount++;
		}
	}
	if ( nlhs == (lhsoutputcount+1) )
		if (stats)
			plhs[lhsoutputcount] = T2mx < vector<double> > (statsoutput);
		else
			plhs[lhsoutputcount] = mxCreateDoubleScalar(0.0);

	// clear out vectors
	points.clear();
	timev.clear();
	te.clear();
	ye.clear();
	ie.clear();
	yout.clear();
	statsoutput.clear();
}

