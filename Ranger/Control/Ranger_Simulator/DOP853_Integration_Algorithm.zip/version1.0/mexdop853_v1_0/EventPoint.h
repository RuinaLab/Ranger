#ifndef EVENTPOINT_H
#define EVENTPOINT_H

#include <vector>
#include "typedefs.h"
#include <list>

using namespace std;

// Finally some new definitions for event detection

class EventPoint
{
public:
	EventPoint(void);
	EventPoint(unsigned evnum,
		double xev,				// Time stamp
		vector<double> yev,		// Solution point at xev
		double vev,				// VALUE of event function at (xev,yev)
		int iev,				// ISTERMINAL of event function at (xev,yev)
		int dev);				// DIRECTION of event function at (xev,yev)
	EventPoint(unsigned evnum,
			double xev,
			vector<double>yev);		// Overloaded version for calculating the vector field data
	EventPoint(unsigned evnum,
			double xev);		// Overloaded version for calculating the event point given only the time-stamp

	void initialize(unsigned evnum,
		double xev,				// Time stamp
		vector<double> yev,		// Solution point at xev
		double vev,				// VALUE of event function at (xev,yev)
		int iev,				// ISTERMINAL of event function at (xev,yev)
		int dev);				// DIRECTION of event function at (xev,yev)
	void initialize(unsigned evnum,
			double xev,
			vector<double>yev);		// Overloaded version for calculating the vector field data
	void initialize(unsigned evnum,
		double xev);			// Overloaded version for calculating the event point given only the time-stamp

	EventPoint & operator=(const EventPoint &rhs);	// Assignment operator for two EVENTPOINTs
	EventPoint & operator=(const double &xev);		// Assignment operator for calculating the event point from time-stamp
	friend EventPoint operator+(const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend EventPoint operator+(const EventPoint &leftpoint, const double &rightDT);
	friend EventPoint operator+(const double &leftDT, const EventPoint &rightpoint);
	friend bool operator==(const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend bool operator!=(const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend bool operator> (const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend bool operator>=(const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend bool operator< (const EventPoint &leftpoint, const EventPoint &rightpoint);
	friend bool operator<=(const EventPoint &leftpoint, const EventPoint &rightpoint);

	friend EventPoint extrapolatepoints(const EventPoint &point1, const EventPoint &point2, const double &targettime);
	void redoeventcalc(unsigned evnum);
	int sign(void);					// The sign of this event point's "value"

	double time, value;
	vector <double> vfsoln;
	int isterminal, direction;
	unsigned eventnumber;

	EvFunType eventf;
};

typedef vector<EventPoint> EventBracket;		// (2 x 1) vector of eventpoints defines an open interval
typedef list<EventBracket> EventBracketList;	// (M x 1) list will store all brackets in which events could occur
typedef list<EventPoint> EventLocationList;		// (E x 1) sorted list of eventpoints where events occur

extern EventPoint extrapolatepoints(const EventPoint &point1, const EventPoint &point2, const double &targettime);

#endif

