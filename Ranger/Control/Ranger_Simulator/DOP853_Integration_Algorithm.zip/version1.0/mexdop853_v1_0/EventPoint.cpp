#include "EventPoint.h"
#include "EventObj.h"
#include <vector>
#include "integrator.h"
//#include "mexdop853.h"
#include "globals.h"
#include "typedefs.h"
#include "templates.h"

using namespace std;

EventPoint::EventPoint(void)
: eventf(events.eventf)
{
}

EventPoint::EventPoint(unsigned evnum, double xev, vector<double>yev, double vev, int iev,int dev)
{
	eventnumber = evnum;
	time = xev;
	vfsoln = yev;
	value = vev;
	isterminal = iev;
	direction = dev;
	eventf = events.eventf;
}

EventPoint::EventPoint(unsigned evnum, double xev)
{
	eventnumber = evnum;
	eventf = events.eventf;
	time = xev;
	vfsoln.assign(events.ndims,0);
	for (int i=0; i<events.ndims; i++)
		vfsoln[i] = contd8(i, time);
	eventf(events.ndims,time,&(vfsoln[0]),events.odeparams,eventnumber,value,isterminal,direction);
}

EventPoint::EventPoint(unsigned evnum, double xev, vector<double>yev)
{
	eventnumber = evnum;
	eventf = events.eventf;
	time = xev;
	vfsoln = yev;
	eventf(events.ndims,time,&(vfsoln[0]),events.odeparams,eventnumber,value,isterminal,direction);
}

void EventPoint::initialize(unsigned evnum, double xev, vector<double>yev, double vev, int iev,int dev)
{
	eventnumber = evnum;
	time = xev;
	vfsoln = yev;
	value = vev;
	isterminal = iev;
	direction = dev;
	eventf = events.eventf;
}

void EventPoint::initialize(unsigned evnum, double xev, vector<double>yev)
{
	eventnumber = evnum;
	eventf = events.eventf;
	time = xev;
	vfsoln = yev;
	eventf(events.ndims,time,&(vfsoln[0]),events.odeparams,eventnumber,value,isterminal,direction);
}

void EventPoint::initialize(unsigned evnum, double xev)
{
	eventnumber = evnum;
	eventf = events.eventf;
	time = xev;
	vfsoln.assign(events.ndims,0);
	for (int i=0; i<events.ndims; i++)
		vfsoln[i] = contd8(i, time);
	eventf(events.ndims,time,&(vfsoln[0]),events.odeparams,eventnumber,value,isterminal,direction);
}

int EventPoint::sign(void)
{
	return signof<double>(value);
}

EventPoint& EventPoint::operator =(const EventPoint &rhs)
{
	if ( this != &rhs )	// To account for self assignment
	{
		eventnumber = rhs.eventnumber;
		time = rhs.time;
		vfsoln = rhs.vfsoln;
		value = rhs.value;
		isterminal = rhs.isterminal;
		direction = rhs.direction;
	}

	return *this;
}

EventPoint& EventPoint::operator =(const double &xev)
{
	eventnumber = events.curevent;
	time = xev;
	for (int i=0; i<events.ndims; i++)
		vfsoln[i] = contd8(i, time);
	eventf(events.ndims,time,&(vfsoln[0]),events.odeparams,eventnumber,value,isterminal,direction);

	return *this;
}


EventPoint operator+(const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return EventPoint(leftpoint.eventnumber, leftpoint.time + rightpoint.time ); // assumes that point have the same eventnumber
}

EventPoint operator+(const EventPoint &leftpoint, const double &rightDT)
{
	return EventPoint(leftpoint.eventnumber,  leftpoint.time + rightDT );
}

EventPoint operator+(const double &leftDT, const EventPoint &rightpoint)
{
	return (rightpoint + leftDT);
}

bool operator==(const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	bool output=true;

	output = ( output && (leftpoint.time == rightpoint.time) );
	output = ( output && (leftpoint.value == rightpoint.value) );
	output = ( output && (leftpoint.vfsoln == rightpoint.vfsoln) );
	output = ( output && (leftpoint.eventnumber == rightpoint.eventnumber) );

	return output;
}

bool operator!=(const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return !(leftpoint == rightpoint);
}

bool operator> (const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return (leftpoint.time > rightpoint.time);
}

bool operator>=(const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return ( (leftpoint>rightpoint) || (leftpoint==rightpoint) );
}

bool operator< (const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return !(leftpoint>=rightpoint);
}

bool operator<=(const EventPoint &leftpoint, const EventPoint &rightpoint)
{
	return !(leftpoint>rightpoint);
}

EventPoint extrapolatepoints(const EventPoint &point1, const EventPoint &point2, const double &targettime)
{
	EventPoint outputpoint;

	outputpoint.time = targettime;
	outputpoint.value = point1.value + (point2.value - point1.value)*
		(outputpoint.time - point1.time)/(point2.time - point1.time);
	// The extrapolated point is a strange point anyway, so let's leave the other
	// member variables without any values.

	return outputpoint;
}

void EventPoint::redoeventcalc(unsigned evnum)
{
	double correctval;
	int correctist, correctdir;

	this->eventnumber = evnum;
	eventf(events.ndims,this->time,&(this->vfsoln[0]),events.odeparams,
		this->eventnumber,correctval,correctist,correctdir);
	this->value = correctval;
	this->isterminal = correctist;
	this->direction = correctdir;
}

