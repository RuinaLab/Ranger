/*	This will contain all the function declarations for converting
between various mx* formats native C++ formats such as vector,
double, int, etc. */

#ifndef TEMPLATES_H
#define TEMPLATES_H

#include <vector>
#include <string>
#include "matrix.h"
// These implementations are all based on ODETOOLS. The implementation is a little strange.
// A template struct of type mexConvert is first defined. It has two member functions
// called mx2T and T2mx. Then, for a general class T, the member functions just use the default.
// This is followed by 4 specializations of the struct type mexConvert
//		1. int
//		2. double
//		3. vector<T>
//		4. vector< vector<T> >
// Finally, there are two global function templates for T2cell and cell2T

using namespace std;

// template for struct type mexConvert
template <typename T>
struct mexConvert {
	T mx2T(const mxArray *m) const { return T(); } // Default definition: use the constructor for T
	mxArray* T2mx(const T& t) const { return NULL; } // Default definition: return NULL
};

// declaration of member functions of mexConvert
template <typename T>
extern T mx2T(const mxArray* m);

template <typename T>
extern mxArray* T2mx(const T& t);

// declaration of int specialization
template <>
struct mexConvert<int> {
	int mx2T(const mxArray *m) const;
	mxArray* T2mx(const int& s) const;
};

// declaration of long specialization
template <>
struct mexConvert<long> {
	long mx2T(const mxArray *m) const;
	mxArray* T2mx(const long& s) const;
};

// declaration of unsigned specialization
template <>
struct mexConvert<unsigned> {
	unsigned mx2T(const mxArray *m) const;
	mxArray* T2mx(const unsigned& s) const;
};

// declaration of double specialization
template <>
struct mexConvert<double> {
	double mx2T(const mxArray *m) const;
	mxArray* T2mx(const double& d) const;
};

// declaration of vector<T> specialization
template <typename T>
struct mexConvert< vector<T> > {
	vector<T> mx2T(const mxArray* m) const;
	mxArray* T2mx(const vector<T>& v) const;
};

// declaration of vector< vector<T> > specialization
template <typename T>
struct mexConvert< vector< vector<T> > > {
	vector< vector<T> > mx2T(const mxArray *m) const;
	mxArray* T2mx(const vector< vector<T> >& v) const;
};

// declaration of string specialization
template <>
struct mexConvert<string> {
	string mx2T(const mxArray *m) const;
	mxArray* T2mx(const string& s) const;
};


// declaration of cell2T and T2cell functions
template <typename T>
extern vector<T> cell2T(const mxArray *m);

template <typename T>
extern mxArray* T2cell(const vector<T>& t);

template <typename T>
extern
int signof(const T& t);


#endif

