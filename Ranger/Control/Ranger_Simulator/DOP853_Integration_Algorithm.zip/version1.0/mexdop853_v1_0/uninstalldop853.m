function uninstalldop853()
%
%
if ispref('mexdop853');
    srcdir = getpref('mexdop853','srcpath');
    installedfiles = getpref('mexdop853','installedfiles');
    installeddirs = getpref('mexdop853','installeddirs');
    for i = 1:length(installedfiles)
        delete(installedfiles{i});
    end
    for i = 1:length(installeddirs)
        rmdir(installeddirs{i});
    end
    fprintf('MEXDOP853: Removed all orginally installed files from the folder -\n');
    disp(srcdir);
    fprintf('-----\n');
    fprintf('There may be some files and folders that were not deleted, please check manually.\n\n');
    rmpref('mexdop853');
    rmpath(srcdir);
else
    fprintf('MEXDOP853 is not installed on this machine.\n\n');
end

end