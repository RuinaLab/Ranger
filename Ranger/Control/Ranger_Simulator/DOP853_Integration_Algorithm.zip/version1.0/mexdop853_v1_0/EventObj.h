#ifndef EVENTOBJ_H
#define EVENTOBJ_H

#include <vector>
#include "matrix.h"
#include "typedefs.h"
#include "OptionsObj.h"
#include "EventPoint.h"

using namespace std;

class EventObj {

public:
	// Default constructor for the EventObj class
	EventObj(void);
	// Initializer for the EventObj class
	void initialize(unsigned ndimsin,
		vector<double> tspanin,
		vector<double> y0in,
		OptionsObj optionsin,
		mxArray* odeparamsvecin,
		EvFunType evnfunname);

	// TESTFOREVENTS is called at every successful integration step. It loops over all event functions.
	EventFlag testforevents(double x, double *y);

	friend class EventPoint;
	EvFunType eventf;

private:
	// The following parameters tell us something about the vector-field and set at object initialization
	unsigned ndims;					// The number of dimensions of vectorfield
	mxArray* odeparams;				// The parameters used by ODEFUN

	// Some other useful parameters that will be set at object construction
	double macheps;

	// The following parameters are used by various event detection/location routines
	unsigned nevents, curevent;	// nevents = optionsin.Events, curevent just tracks the event function number being considered
	double eventtol;				// Tolerance for event location (user input)
	int maxeventsteps;				// The maximum number of steps to take in trying to locate an event.
	int maxeventdepth;				// No. recursions when looking for multiple crossings
	//double eventdelay;			// The delay parameter before starting event detection (user input): not yet been implemented
	unsigned niterdetect, niterlocate;

	// A few variables to track the previous and current integration points
	vector <EventPoint> pointprev, pointcur;

	EventBracketList eventdetect(EventPoint & event1, EventPoint &event2);
	EventPoint eventlocatebrent(EventPoint & event1, EventPoint & event2);
	friend EventBracket makebracket(EventPoint & event1, EventPoint & event2);
};

extern EventBracket makebracket(EventPoint & event1, EventPoint & event2);

#endif

