#ifndef OPTIONSOBJ_H
#define OPTIONSOBJ_H

#include "matrix.h"
#include <string>

using namespace std;

class OptionsObj {
public:
  OptionsObj();
  OptionsObj(const mxArray*);

  double AbsTol;
  double Beta;
  unsigned Events; // if 0, no events, else equal to number of events to be detected
  double EventDelay;
  double EventTol;
  double Fac1;
  double Fac2;
  double InitialStep;
  double MachEps;
  unsigned MaxBisect;
  unsigned MaxEventRecursions;
  long MaxSteps;
  double MaxStepSize;
  unsigned Refine;
  double RelTol;
  double Safety;
  bool Stats;
};

#endif

