function installdop853()
% INSTALLDOP853    Installation script for MEXDOP853 v1.0
%       This script will be accompanied by a ZIP file. In case there is no
%       ZIP file, it will use a prespecified URL to download the latest ZIP
%       file for copying over.
%
%       Madhusudhan Venkadesan, 4 April 2008.
%

VERSION = '1.0';

if ispref('mexdop853')
    curversion = getpref('mexdop853','version');
    cursrcpath = getpref('mexdop853','srcpath');
    errordlg({['Verion ' curversion ' of MEXDOP853 is already installed in'],...
        cursrcpath,...
        'Run the included uninstaller first before continuing.'},...
        'Error: Already Installed',...
        'modal');
    return
end

% 1. Ask for whether MEX needs to be setup. If so, do it.
mexquestion = questdlg({'Has a compiler for MEX been setup on your machine?',...
                        'If you answer ''''No'''' the MEX setup process will be started.'},...
                       'MEX Question',...
                       'Yes','No','Quit Install','Quit Install');
switch(mexquestion)
    case 'Quit Install'
        error('MEXDOP853:InstallationAborted','Installation aborted by user.');
    case 'No'
        fprintf('Launching the setup process for MEX...\n\n');
        feval(@mex,'-setup');
end

% 2. Ask if GSL exists and if so, ask for the location.
gslquestion = questdlg({'Do you have compiled GSL static libraries,', 'and do you want to use them with MEXDOP853?'},...
                       'GSL Question',...
                       'Yes','No','Quit Install','No');
switch (gslquestion)
    case 'Quit Install'
        error('MEXDOP853:InstallationAborted','Installation aborted by user.');
    case 'No'
        gslpath = '';
    case 'Yes'
        gslpath = uigetdir('','Select where GSL is located');
        if gslpath==0
            gslpath = '';
        end
end

% 3. Ask for the location of the installation folder.
srcpath = fullfile(matlabroot,'work','mexdop853');
srcpath = uigetdir(srcpath,'Select location for installing MEXDOP853');
if srcpath==0
    error('MEXDOP853:InstallationAborted','Installation aborted by user.');
end

% 4. Copy all the appropriate files and folders over to the installation
%    folder.
% unzip('http://www.math.cornell.edu/~madhu/mexdop853/mexdop853_v1_0.zip',srcpath);
unzip('mexdop853_v1_0.zip',srcpath);
[installedfiles,installeddirs] = getfilenames(srcpath);

% 5. Setup srcpath, gslpath and verion as system-wide preferences under the
% PREF structure mexdop853
addpref('mexdop853',...
    {'srcpath','gslpath','version','installedfiles','installeddirs'},...
    {srcpath,gslpath,VERSION,installedfiles,installeddirs});
addpath(srcpath);
out=savepath;
if out
    fprintf('\nFailed to add the MEXDOP853 installation folder to MATLAB path.\n');
    fprintf('This is most probably because you don''t have write permissions for pathdef.m\n');
    fprintf('Add MEXDOP853 installation path to startup.m or pathdef.m for ease of use.\n\n');
end
rehash;

% 6. Print success message
disp(['Done installing MEXDOP853 v' VERSION]);
disp('  ');

end

function [filelisting,dirlisting] = getfilenames(dirname)
%
filelisting = [];
dirlisting = [];
olddir = pwd;
cd(dirname);
allstuff = dir(dirname);
for i = 1:length(allstuff);
    if ~(strcmpi(allstuff(i).name,'.') || strcmpi(allstuff(i).name,'..'))
        if isdir(allstuff(i).name)
            curdir = fullfile(dirname,allstuff(i).name);
            [filebuff,dirbuff] = getfilenames(curdir);
            filelisting = [filelisting;filebuff];
            dirlisting = [dirlisting;{curdir};dirbuff];
        else
            filelisting = [filelisting;{fullfile(dirname,allstuff(i).name)}];
        end
    end
end
cd(olddir);

end 